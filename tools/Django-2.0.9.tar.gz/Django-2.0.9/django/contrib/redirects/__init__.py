default_app_config = 'django.contrib.redirects.apps.RedirectsConfig'
