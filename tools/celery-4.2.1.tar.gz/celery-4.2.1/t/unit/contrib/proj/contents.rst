.. automodule:: foo
