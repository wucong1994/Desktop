=======================================
 ``celery.apps.multi``
=======================================

.. contents::
    :local:
.. currentmodule:: celery.apps.multi

.. automodule:: celery.apps.multi
    :members:
    :undoc-members:
