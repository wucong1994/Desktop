=====================================================
 ``celery.bin.control``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.bin.control

.. automodule:: celery.bin.control
    :members:
    :undoc-members:
