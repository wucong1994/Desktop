=====================================
 ``celery.backends.async``
=====================================

.. contents::
    :local:
.. currentmodule:: celery.backends.async

.. automodule:: celery.backends.async
    :members:
    :undoc-members:


