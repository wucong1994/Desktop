==========================================
 ``celery.utils.deprecated``
==========================================

.. contents::
    :local:
.. currentmodule:: celery.utils.deprecated

.. automodule:: celery.utils.deprecated
    :members:
    :undoc-members:
