============================================
 ``celery.utils.serialization``
============================================

.. contents::
    :local:
.. currentmodule:: celery.utils.serialization

.. automodule:: celery.utils.serialization
    :members:
    :undoc-members:
