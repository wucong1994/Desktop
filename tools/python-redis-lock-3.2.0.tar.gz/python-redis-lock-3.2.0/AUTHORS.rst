
Authors
=======

* Ionel Cristian Mărieș - https://blog.ionelmc.ro
* Rob Terhaar - https://github.com/robbyt
* Corey Farwell - http://rwell.org
* Yokotoka - http://yokotoka.ru
* Jardel Weyrich - http://twitter.com/jweyrich
* Victor Torres - http://github.com/victor-torres
* Andrew Pashkin - https://github.com/AndrewPashkin
* Tero Vuotila - https://github.com/tvuotila
* Joel Höner - https://github.com/athre0z
