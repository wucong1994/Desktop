============
Installation
============

At the command line::

    pip install python-redis-lock
